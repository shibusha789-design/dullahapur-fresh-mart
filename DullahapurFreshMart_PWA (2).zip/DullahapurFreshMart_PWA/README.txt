DULLAHAPUR FRESH MART - PWA

EASY COMPUTER PREVIEW
1. Extract this ZIP.
2. Double-click index.html to preview the website.

INSTALL AS AN APP
For Chrome's Install App option, the website must be opened from a web address (HTTPS) or localhost; file:// pages cannot install a PWA.

EASIEST LOCAL TEST (Windows with Python installed):
1. Open this folder.
2. Click the address bar, type cmd, press Enter.
3. Type: py -m http.server 8000
4. On the same PC open: http://localhost:8000
5. In Chrome, open the menu. If supported, choose Install Dullahapur Fresh Mart / Install app.

PHONE INSTALL
To install on an Android phone, the PWA needs to be hosted on an HTTPS website. Once hosted, open the site in Chrome on the phone and choose Install app / Add to Home screen.

NOTE
The online payment screen in this demo is an interface; a real payment gateway (UPI/card provider and merchant account) must be connected before accepting live payments.
